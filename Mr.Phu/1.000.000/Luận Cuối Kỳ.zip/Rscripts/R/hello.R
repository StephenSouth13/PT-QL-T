# ==============================================================================
# ĐỀ ÁN CÁ NHÂN: PHÂN TÍCH VÀ QUẢN TRỊ DANH MỤC ĐẦU TƯ
# Sinh viên thực hiện: Nguyễn Xuân Phú
# Giảng viên hướng dẫn: Lê Văn Lâm - UEH
# ==============================================================================

# 1. KHAI BÁO THƯ VIỆN CHUYÊN DỤNG
library(quantmod)
library(PerformanceAnalytics)
library(tseries)
library(fBasics)

# 2. THIẾT LẬP DANH MỤC VÀ TẢI DỮ LIỆU THỰC TẾ (2024-2026)
# Danh mục: MBB, VNM, FPT, VIC, PLX
symbols <- c("MBB.VN", "VNM.VN", "FPT.VN", "VIC.VN", "PLX.VN")
getSymbols(symbols, src = "yahoo", from = "2024-04-10", to = "2026-04-10")

# Trích xuất giá đóng cửa và tính tỷ suất sinh lời (Log Returns)
prices <- merge(Cl(MBB.VN), Cl(VNM.VN), Cl(FPT.VN), Cl(VIC.VN), Cl(PLX.VN))
colnames(prices) <- c("MBB", "VNM", "FPT", "VIC", "PLX")
returns <- na.omit(Return.calculate(prices, method = "log"))

# 3. CHƯƠNG 1 & 2: THỐNG KÊ MÔ TẢ VÀ KIỂM ĐỊNH PHÂN PHỐI
# Tính toán lợi nhuận trung bình năm và độ lệch chuẩn
stats_summary <- data.frame(
  Mean_Ann = colMeans(returns) * 250,
  Std_Dev_Ann = apply(returns, 2, sd) * sqrt(250),
  Skewness = apply(returns, 2, skewness),
  Excess_Kurtosis = apply(returns, 2, kurtosis)
)
print("--- THỐNG KÊ MÔ TẢ DANH MỤC ---")
print(stats_summary)

# Vẽ Histogram cho cổ phiếu tiêu biểu (FPT)
chart.Histogram(returns$FPT, methods = c("add.density", "add.normal"),
                main = "Phân phối lợi nhuận FPT (Kiểm định đuôi dày)",
                colorset = "darkgreen")

# 4. CHƯƠNG 3: LÝ THUYẾT DANH MỤC MARKOWITZ
# Ma trận tương quan
corr_matrix <- cor(returns)
print("--- MA TRẬN TƯƠNG QUAN ---")
print(round(corr_matrix, 2))

# Xác lập danh mục phương sai tối thiểu (MVP) cho cặp VIC - PLX
pair_returns <- returns[, c("VIC", "PLX")]
cov_pair <- cov(pair_returns)
w_vic_mvp <- (var(pair_returns$PLX) - cov_pair[1,2]) /
  (var(pair_returns$VIC) + var(pair_returns$PLX) - 2 * cov_pair[1,2])
print(paste("Tỷ trọng MVP tối ưu cho VIC:", round(w_vic_mvp, 4)))

# 5. CHƯƠNG 4: MÔ HÌNH ĐỊNH GIÁ TÀI SẢN VỐN (CAPM)
# Giả lập Market Proxy (Trung bình danh mục) và Lãi suất phi rủi ro
rm <- rowMeans(returns)
rf <- 0.03 / 250
market_excess <- rm - rf

# Hồi quy tuyến tính để tính Beta và Alpha cho MBB
mbb_excess <- returns$MBB - rf
capm_model <- lm(mbb_excess ~ market_excess)
summary(capm_model)

# Vẽ đường Security Market Line (SML)
betas <- apply(returns, 2, function(x) cov(x - rf, market_excess) / var(market_excess))
expected_ret <- colMeans(returns) * 250
plot(betas, expected_ret, main = "Security Market Line (SML) - HOSE 2024-2026",
     xlab = "Hệ số Beta", ylab = "Lợi nhuận kỳ vọng (%)", pch = 18, col = "red")
abline(a = 0.03, b = (mean(rm) * 250 - 0.03), col = "blue", lwd = 2)
text(betas, expected_ret, labels = names(betas), pos = 4, cex = 0.8)

# ==============================================================================
# KẾT THÚC MÃ NGUỒN PHÂN TÍCH
# ==============================================================================
